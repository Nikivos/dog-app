import SwiftUI

struct ContentView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Dog.name, ascending: true)],
        animation: .default)
    private var dogs: FetchedResults<Dog>
    
    @State private var selectedTab = 0
    @State private var showAddDog = false
    
    var body: some View {
        TabView(selection: $selectedTab) {
            DashboardView(dogs: dogs)
                .tabItem {
                    Label("Dashboard", systemImage: "house.fill")
                }
                .tag(0)
            
            CalendarView()
                .tabItem {
                    Label("Calendar", systemImage: "calendar")
                }
                .tag(1)
            
            AnalyticsView()
                .tabItem {
                    Label("Analytics", systemImage: "chart.bar.fill")
                }
                .tag(2)
            
            KnowledgeBaseView()
                .tabItem {
                    Label("Tips", systemImage: "book.fill")
                }
                .tag(3)
            
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gear")
                }
                .tag(4)
        }
        .accentColor(.blue)
        .sheet(isPresented: $showAddDog) {
            AddDogView()
        }
    }
}

struct DashboardView: View {
    let dogs: FetchedResults<Dog>
    @State private var showAddDog = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    if dogs.isEmpty {
                        WelcomeView()
                    } else {
                        ForEach(dogs) { dog in
                            DogCard(dog: dog)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("My Dogs")
            .toolbar {
                Button(action: {
                    showAddDog = true
                }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.title2)
                }
            }
            .sheet(isPresented: $showAddDog) {
                AddDogView()
            }
        }
    }
}

struct DogCard: View {
    let dog: Dog
    
    var body: some View {
        VStack {
            if let imageData = dog.image, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(height: 200)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text(dog.name ?? "Unknown")
                    .font(.title)
                    .fontWeight(.bold)
                
                if let breed = dog.breed {
                    Text(breed)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                HStack {
                    QuickActionButton(title: "Feed", icon: "bowl.fill") {
                        // Feed action
                    }
                    
                    QuickActionButton(title: "Walk", icon: "figure.walk") {
                        // Walk action
                    }
                    
                    QuickActionButton(title: "Health", icon: "heart.fill") {
                        // Health action
                    }
                }
            }
            .padding()
        }
        .background(Color(.systemBackground))
        .cornerRadius(25)
        .shadow(radius: 5)
    }
}

struct QuickActionButton: View {
    let title: String
    let icon: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Image(systemName: icon)
                    .font(.title2)
                Text(title)
                    .font(.caption)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(Color.blue.opacity(0.1))
            .cornerRadius(15)
        }
        .accentColor(.blue)
    }
}

struct WelcomeView: View {
    var body: some View {
        VStack(spacing: 20) {
            LottieView(name: "dog-animation")
                .frame(height: 200)
            
            Text("Welcome to DogCare")
                .font(.title)
                .fontWeight(.bold)
            
            Text("Add your first dog to get started")
                .foregroundColor(.secondary)
            
            Button(action: {
                // Add dog action
            }) {
                Text("Add Dog")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(15)
            }
            .padding(.horizontal)
        }
    }
}

// Placeholder views
struct CalendarView: View {
    var body: some View {
        Text("Calendar View")
    }
}

struct AnalyticsView: View {
    var body: some View {
        Text("Analytics View")
    }
}

struct KnowledgeBaseView: View {
    var body: some View {
        Text("Knowledge Base")
    }
}

struct SettingsView: View {
    var body: some View {
        Text("Settings")
    }
}

struct LottieView: View {
    let name: String
    
    var body: some View {
        Color.clear // Placeholder for Lottie animation
    }
} 