import Foundation
import CoreData
import SwiftUI
import ZIPFoundation

class BackupManager: ObservableObject {
    static let shared = BackupManager()
    
    @Published var isExporting = false
    @Published var isImporting = false
    @Published var error: String?
    
    private let dataController = DataController.shared
    
    // Директория для временных файлов бэкапа
    private var backupDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("Backups", isDirectory: true)
    }
    
    // Создание бэкапа
    func createBackup() async throws -> URL {
        isExporting = true
        error = nil
        defer { isExporting = false }
        
        // Создаем временную директорию для бэкапа
        try FileManager.default.createDirectory(at: backupDirectory, withIntermediateDirectories: true)
        
        // Имя файла бэкапа с датой
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
        let backupName = "DogCare_Backup_\(dateFormatter.string(from: Date())).dcbackup"
        let backupURL = backupDirectory.appendingPathComponent(backupName)
        
        // Получаем URL хранилища CoreData
        guard let storeURL = dataController.container.persistentStoreCoordinator.persistentStores.first?.url else {
            throw BackupError.storeNotFound
        }
        
        // Создаем архив
        guard let archive = Archive(url: backupURL, accessMode: .create) else {
            throw BackupError.archiveCreationFailed
        }
        
        // Добавляем файл базы данных в архив
        try archive.addEntry(with: "database.sqlite", fileURL: storeURL)
        
        // Добавляем UserDefaults
        let defaults = UserDefaults.standard
        let defaultsDict = defaults.dictionaryRepresentation()
        let defaultsData = try JSONSerialization.data(withJSONObject: defaultsDict)
        let defaultsURL = backupDirectory.appendingPathComponent("userdefaults.json")
        try defaultsData.write(to: defaultsURL)
        try archive.addEntry(with: "userdefaults.json", fileURL: defaultsURL)
        
        // Очищаем временные файлы
        try FileManager.default.removeItem(at: defaultsURL)
        
        return backupURL
    }
    
    // Восстановление из бэкапа
    func restoreFromBackup(url: URL) async throws {
        isImporting = true
        error = nil
        defer { isImporting = false }
        
        // Проверяем формат файла
        guard url.pathExtension == "dcbackup" else {
            throw BackupError.invalidFileFormat
        }
        
        // Открываем архив
        guard let archive = Archive(url: url, accessMode: .read) else {
            throw BackupError.invalidArchive
        }
        
        // Создаем временную директорию для распаковки
        let tempDir = backupDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)
        
        // Распаковываем архив
        for entry in archive {
            let entryURL = tempDir.appendingPathComponent(entry.path)
            _ = try archive.extract(entry, to: entryURL)
        }
        
        // Восстанавливаем базу данных
        let databaseURL = tempDir.appendingPathComponent("database.sqlite")
        guard let storeURL = dataController.container.persistentStoreCoordinator.persistentStores.first?.url else {
            throw BackupError.storeNotFound
        }
        
        // Закрываем текущее хранилище
        try dataController.container.persistentStoreCoordinator.replacePersistentStore(
            at: storeURL,
            destinationOptions: nil,
            withPersistentStoreFrom: databaseURL,
            sourceOptions: nil,
            ofType: NSSQLiteStoreType
        )
        
        // Восстанавливаем UserDefaults
        let defaultsURL = tempDir.appendingPathComponent("userdefaults.json")
        let defaultsData = try Data(contentsOf: defaultsURL)
        if let defaultsDict = try JSONSerialization.jsonObject(with: defaultsData) as? [String: Any] {
            for (key, value) in defaultsDict {
                UserDefaults.standard.set(value, forKey: key)
            }
        }
        
        // Очищаем временные файлы
        try FileManager.default.removeItem(at: tempDir)
        
        // Перезагружаем контекст
        dataController.container.viewContext.reset()
    }
}

enum BackupError: LocalizedError {
    case storeNotFound
    case archiveCreationFailed
    case invalidFileFormat
    case invalidArchive
    
    var errorDescription: String? {
        switch self {
        case .storeNotFound:
            return "База данных не найдена"
        case .archiveCreationFailed:
            return "Не удалось создать архив"
        case .invalidFileFormat:
            return "Неверный формат файла бэкапа"
        case .invalidArchive:
            return "Архив поврежден или имеет неверный формат"
        }
    }
} 