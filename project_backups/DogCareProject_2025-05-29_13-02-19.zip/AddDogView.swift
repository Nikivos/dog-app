import SwiftUI
import PhotosUI

struct AddDogView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var name = ""
    @State private var breed = ""
    @State private var birthDate = Date()
    @State private var weight = ""
    @State private var healthNotes = ""
    @State private var selectedImage: UIImage?
    @State private var showingImagePicker = false
    @State private var showingAlert = false
    @State private var alertMessage = ""
    
    private let maxImageSize: Int64 = 5 * 1024 * 1024 // 5MB
    
    var isValidWeight: Bool {
        guard let weightValue = Double(weight) else { return false }
        return weightValue > 0 && weightValue < 200 // Reasonable weight range for dogs
    }
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Photo")) {
                    HStack {
                        Spacer()
                        Button(action: { showingImagePicker = true }) {
                            if let image = selectedImage {
                                Image(uiImage: image)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                                    .clipShape(Circle())
                            } else {
                                Image(systemName: "camera.circle.fill")
                                    .font(.system(size: 100))
                                    .foregroundColor(.blue)
                            }
                        }
                        Spacer()
                    }
                    .padding(.vertical)
                }
                
                Section(header: Text("Basic Information")) {
                    TextField("Name", text: $name)
                    TextField("Breed", text: $breed)
                    DatePicker("Birth Date", selection: $birthDate, displayedComponents: .date)
                    TextField("Weight (kg)", text: $weight)
                        .keyboardType(.decimalPad)
                        .onChange(of: weight) { newValue in
                            weight = newValue.filter { "0123456789.".contains($0) }
                        }
                }
                
                Section(header: Text("Health Notes")) {
                    TextEditor(text: $healthNotes)
                        .frame(height: 100)
                }
            }
            .navigationTitle("Add Dog")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        if validateAndSave() {
                            dismiss()
                        }
                    }
                    .disabled(name.isEmpty || !isValidWeight)
                }
            }
            .alert("Error", isPresented: $showingAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(alertMessage)
            }
            .sheet(isPresented: $showingImagePicker) {
                ImagePicker(image: $selectedImage)
            }
        }
    }
    
    private func validateAndSave() -> Bool {
        // Validate weight
        guard let weightValue = Double(weight), weightValue > 0, weightValue < 200 else {
            alertMessage = "Please enter a valid weight between 0 and 200 kg"
            showingAlert = true
            return false
        }
        
        // Validate image size
        if let image = selectedImage,
           let imageData = image.jpegData(compressionQuality: 0.8),
           Int64(imageData.count) > maxImageSize {
            alertMessage = "Image size is too large. Please choose a smaller image (max 5MB)"
            showingAlert = true
            return false
        }
        
        // Save the dog
        let newDog = Dog(context: viewContext)
        newDog.id = UUID()
        newDog.name = name
        newDog.breed = breed
        newDog.birthDate = birthDate
        newDog.weight = weightValue
        newDog.healthNotes = healthNotes
        
        if let image = selectedImage,
           let imageData = image.jpegData(compressionQuality: 0.8) {
            newDog.image = imageData
        }
        
        do {
            try viewContext.save()
            return true
        } catch {
            alertMessage = "Error saving dog: \(error.localizedDescription)"
            showingAlert = true
            return false
        }
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    @Environment(\.dismiss) private var dismiss
    
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration()
        config.filter = .images
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: ImagePicker
        
        init(_ parent: ImagePicker) {
            self.parent = parent
        }
        
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            parent.dismiss()
            
            guard let provider = results.first?.itemProvider else { return }
            
            if provider.canLoadObject(ofClass: UIImage.self) {
                provider.loadObject(ofClass: UIImage.self) { image, _ in
                    DispatchQueue.main.async {
                        self.parent.image = image as? UIImage
                    }
                }
            }
        }
    }
} 