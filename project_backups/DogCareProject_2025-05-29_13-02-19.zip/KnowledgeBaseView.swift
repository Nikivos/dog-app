import SwiftUI

struct KnowledgeBaseView: View {
    @State private var selectedCategory = Category.nutrition
    
    enum Category: String, CaseIterable {
        case nutrition = "Nutrition"
        case health = "Health"
        case training = "Training"
        case grooming = "Grooming"
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // Category selector
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach(Category.allCases, id: \.self) { category in
                                CategoryButton(
                                    category: category,
                                    isSelected: selectedCategory == category
                                ) {
                                    selectedCategory = category
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                    
                    // Content for selected category
                    switch selectedCategory {
                    case .nutrition:
                        NutritionView()
                    case .health:
                        HealthView()
                    case .training:
                        TrainingView()
                    case .grooming:
                        GroomingView()
                    }
                }
            }
            .navigationTitle("Tips & Guides")
        }
    }
}

struct CategoryButton: View {
    let category: KnowledgeBaseView.Category
    let isSelected: Bool
    let action: () -> Void
    
    var icon: String {
        switch category {
        case .nutrition: return "fork.knife"
        case .health: return "heart.fill"
        case .training: return "figure.walk"
        case .grooming: return "scissors"
        }
    }
    
    var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 24))
                Text(category.rawValue)
                    .font(.caption)
            }
            .foregroundColor(isSelected ? .white : .primary)
            .frame(width: 80, height: 80)
            .background(isSelected ? Color.blue : Color(.systemBackground))
            .cornerRadius(12)
            .shadow(radius: 2)
        }
    }
}

struct NutritionView: View {
    var body: some View {
        VStack(spacing: 20) {
            // Food calculator
            InfoCard(title: "Food Calculator", icon: "function") {
                VStack(alignment: .leading, spacing: 12) {
                    Text("Calculate daily food portions based on:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    HStack {
                        InfoPill(text: "Weight")
                        InfoPill(text: "Age")
                        InfoPill(text: "Activity Level")
                    }
                    
                    NavigationLink("Calculate Now") {
                        Text("Food Calculator") // TODO: Implement calculator view
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
            
            // Safe foods list
            InfoCard(title: "Safe Foods", icon: "checkmark.circle") {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(safeFoods, id: \.name) { food in
                        HStack {
                            Image(systemName: "leaf.fill")
                                .foregroundColor(.green)
                            Text(food.name)
                            Spacer()
                            Text(food.benefit)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Divider()
                    }
                }
            }
            
            // Dangerous foods list
            InfoCard(title: "Foods to Avoid", icon: "exclamationmark.triangle") {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(dangerousFoods, id: \.name) { food in
                        HStack {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.red)
                            Text(food.name)
                            Spacer()
                            Text(food.reason)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Divider()
                    }
                }
            }
        }
        .padding(.horizontal)
    }
    
    private let safeFoods = [
        Food(name: "Lean Chicken", benefit: "Protein"),
        Food(name: "Carrots", benefit: "Vitamin A"),
        Food(name: "Sweet Potatoes", benefit: "Fiber"),
        Food(name: "Greek Yogurt", benefit: "Probiotics")
    ]
    
    private let dangerousFoods = [
        Food(name: "Chocolate", reason: "Toxic"),
        Food(name: "Grapes", reason: "Kidney damage"),
        Food(name: "Onions", reason: "Blood cells damage"),
        Food(name: "Xylitol", reason: "Very toxic")
    ]
}

struct HealthView: View {
    var body: some View {
        VStack(spacing: 20) {
            InfoCard(title: "Vaccination Schedule", icon: "syringe") {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(vaccinations, id: \.name) { vaccination in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(vaccination.name)
                                .font(.headline)
                            Text(vaccination.schedule)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Divider()
                    }
                }
            }
            
            InfoCard(title: "Common Symptoms", icon: "stethoscope") {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(symptoms, id: \.name) { symptom in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(symptom.name)
                                .font(.headline)
                            Text(symptom.action)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Divider()
                    }
                }
            }
        }
        .padding(.horizontal)
    }
    
    private let vaccinations = [
        Vaccination(name: "DHPP", schedule: "Every 3 years after initial series"),
        Vaccination(name: "Rabies", schedule: "Annually or every 3 years"),
        Vaccination(name: "Bordetella", schedule: "Every 6-12 months"),
        Vaccination(name: "Lyme", schedule: "Annually (if in endemic area)")
    ]
    
    private let symptoms = [
        Symptom(name: "Vomiting", action: "Fast for 12 hours, then bland diet"),
        Symptom(name: "Diarrhea", action: "Rice and chicken diet, plenty of water"),
        Symptom(name: "Lethargy", action: "Monitor and consult vet if persistent"),
        Symptom(name: "Loss of Appetite", action: "Consult vet if over 24 hours")
    ]
}

struct TrainingView: View {
    var body: some View {
        VStack(spacing: 20) {
            InfoCard(title: "Basic Commands", icon: "command") {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(commands, id: \.name) { command in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(command.name)
                                .font(.headline)
                            Text(command.instructions)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Divider()
                    }
                }
            }
            
            InfoCard(title: "Training Tips", icon: "star") {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(tips, id: \.title) { tip in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(tip.title)
                                .font(.headline)
                            Text(tip.description)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Divider()
                    }
                }
            }
        }
        .padding(.horizontal)
    }
    
    private let commands = [
        Command(name: "Sit", instructions: "Hold treat above head, move back"),
        Command(name: "Stay", instructions: "Use hand signal, increase distance gradually"),
        Command(name: "Come", instructions: "Use excited voice, reward immediately"),
        Command(name: "Leave it", instructions: "Place treat on ground, reward for ignoring")
    ]
    
    private let tips = [
        Tip(title: "Consistency", description: "Use same commands and rewards"),
        Tip(title: "Timing", description: "Reward within 2 seconds of behavior"),
        Tip(title: "Short Sessions", description: "Train for 5-10 minutes at a time"),
        Tip(title: "Positive Reinforcement", description: "Always reward good behavior")
    ]
}

struct GroomingView: View {
    var body: some View {
        VStack(spacing: 20) {
            InfoCard(title: "Grooming Schedule", icon: "calendar") {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(groomingTasks, id: \.task) { grooming in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(grooming.task)
                                .font(.headline)
                            Text(grooming.frequency)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Divider()
                    }
                }
            }
            
            InfoCard(title: "Grooming Tips", icon: "sparkles") {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(groomingTips, id: \.title) { tip in
                        VStack(alignment: .leading, spacing: 4) {
                            Text(tip.title)
                                .font(.headline)
                            Text(tip.description)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        Divider()
                    }
                }
            }
        }
        .padding(.horizontal)
    }
    
    private let groomingTasks = [
        GroomingTask(task: "Brushing", frequency: "2-3 times per week"),
        GroomingTask(task: "Bath", frequency: "Every 4-8 weeks"),
        GroomingTask(task: "Nail Trimming", frequency: "Every 2-4 weeks"),
        GroomingTask(task: "Teeth Brushing", frequency: "2-3 times per week")
    ]
    
    private let groomingTips = [
        GroomingTip(title: "Start Early", description: "Get puppy used to grooming"),
        GroomingTip(title: "Be Gentle", description: "Use positive reinforcement"),
        GroomingTip(title: "Right Tools", description: "Use appropriate brushes for coat type"),
        GroomingTip(title: "Check Skin", description: "Look for irritation or parasites")
    ]
}

struct InfoCard<Content: View>: View {
    let title: String
    let icon: String
    let content: Content
    
    init(title: String, icon: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.icon = icon
        self.content = content()
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Image(systemName: icon)
                    .font(.title2)
                Text(title)
                    .font(.title3)
                    .fontWeight(.bold)
            }
            
            content
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
    }
}

struct InfoPill: View {
    let text: String
    
    var body: some View {
        Text(text)
            .font(.caption)
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(Color.blue.opacity(0.1))
            .foregroundColor(.blue)
            .cornerRadius(12)
    }
}

// Data models
struct Food {
    let name: String
    let benefit: String
    let reason: String?
    
    init(name: String, benefit: String) {
        self.name = name
        self.benefit = benefit
        self.reason = nil
    }
    
    init(name: String, reason: String) {
        self.name = name
        self.reason = reason
        self.benefit = ""
    }
}

struct Vaccination {
    let name: String
    let schedule: String
}

struct Symptom {
    let name: String
    let action: String
}

struct Command {
    let name: String
    let instructions: String
}

struct Tip {
    let title: String
    let description: String
}

struct GroomingTask {
    let task: String
    let frequency: String
}

struct GroomingTip {
    let title: String
    let description: String
} 