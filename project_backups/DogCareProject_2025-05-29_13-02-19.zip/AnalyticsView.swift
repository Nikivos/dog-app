import SwiftUI
import Charts

struct AnalyticsView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Dog.name, ascending: true)],
        animation: .default)
    private var dogs: FetchedResults<Dog>
    
    @State private var selectedDog: Dog?
    @State private var selectedTimeRange = TimeRange.week
    
    enum TimeRange: String, CaseIterable {
        case week = "Week"
        case month = "Month"
        case year = "Year"
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                if let dog = selectedDog ?? dogs.first {
                    VStack(spacing: 20) {
                        // Dog selector
                        if dogs.count > 1 {
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 10) {
                                    ForEach(dogs) { dog in
                                        DogSelectorButton(
                                            dog: dog,
                                            isSelected: selectedDog == dog
                                        ) {
                                            selectedDog = dog
                                        }
                                    }
                                }
                                .padding(.horizontal)
                            }
                        }
                        
                        // Time range selector
                        Picker("Time Range", selection: $selectedTimeRange) {
                            ForEach(TimeRange.allCases, id: \.self) { range in
                                Text(range.rawValue).tag(range)
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding(.horizontal)
                        
                        // Weight chart
                        ChartCard(title: "Weight History") {
                            Chart {
                                ForEach(weightData(for: dog), id: \.date) { data in
                                    LineMark(
                                        x: .value("Date", data.date),
                                        y: .value("Weight", data.weight)
                                    )
                                    .foregroundStyle(Color.blue)
                                    
                                    PointMark(
                                        x: .value("Date", data.date),
                                        y: .value("Weight", data.weight)
                                    )
                                    .foregroundStyle(Color.blue)
                                }
                            }
                            .frame(height: 200)
                        }
                        
                        // Activity summary
                        ChartCard(title: "Activity Summary") {
                            Chart {
                                ForEach(activityData(for: dog), id: \.date) { data in
                                    BarMark(
                                        x: .value("Date", data.date),
                                        y: .value("Duration", data.duration)
                                    )
                                    .foregroundStyle(Color.green)
                                }
                            }
                            .frame(height: 200)
                        }
                        
                        // Stats grid
                        LazyVGrid(columns: [
                            GridItem(.flexible()),
                            GridItem(.flexible())
                        ], spacing: 20) {
                            StatCard(
                                title: "Average Walk",
                                value: "\(Int(averageWalkDuration(for: dog))) min",
                                icon: "figure.walk",
                                color: .green
                            )
                            
                            StatCard(
                                title: "Feedings/Day",
                                value: String(format: "%.1f", averageFeedingsPerDay(for: dog)),
                                icon: "bowl.fill",
                                color: .orange
                            )
                        }
                        .padding(.horizontal)
                    }
                } else {
                    Text("Add a dog to see analytics")
                        .foregroundColor(.secondary)
                }
            }
            .navigationTitle("Analytics")
        }
    }
    
    private func weightData(for dog: Dog) -> [(date: Date, weight: Double)] {
        let calendar = Calendar.current
        let endDate = Date()
        let startDate = calendar.date(byAdding: getDateComponent(), to: endDate) ?? endDate
        
        let fetchRequest: NSFetchRequest<HealthRecord> = HealthRecord.fetchRequest()
        fetchRequest.predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            NSPredicate(format: "dog == %@", dog),
            NSPredicate(format: "type == %@", "Weight"),
            NSPredicate(format: "date >= %@ AND date <= %@", startDate as NSDate, endDate as NSDate)
        ])
        fetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \HealthRecord.date, ascending: true)]
        
        do {
            let records = try viewContext.fetch(fetchRequest)
            return records.compactMap { record in
                guard let date = record.date,
                      let notes = record.notes,
                      let weight = Double(notes) else { return nil }
                return (date: date, weight: weight)
            }
        } catch {
            print("Error fetching weight data: \(error)")
            return []
        }
    }
    
    private func activityData(for dog: Dog) -> [(date: Date, duration: Double)] {
        let calendar = Calendar.current
        let endDate = Date()
        let startDate = calendar.date(byAdding: getDateComponent(), to: endDate) ?? endDate
        
        let fetchRequest: NSFetchRequest<DogActivity> = DogActivity.fetchRequest()
        fetchRequest.predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            NSPredicate(format: "dog == %@", dog),
            NSPredicate(format: "type == %@", "Walk"),
            NSPredicate(format: "date >= %@ AND date <= %@", startDate as NSDate, endDate as NSDate)
        ])
        fetchRequest.sortDescriptors = [NSSortDescriptor(keyPath: \DogActivity.date, ascending: true)]
        
        do {
            let activities = try viewContext.fetch(fetchRequest)
            return activities.compactMap { activity in
                guard let date = activity.date else { return nil }
                return (date: date, duration: activity.duration)
            }
        } catch {
            print("Error fetching activity data: \(error)")
            return []
        }
    }
    
    private func averageWalkDuration(for dog: Dog) -> Double {
        let fetchRequest: NSFetchRequest<DogActivity> = DogActivity.fetchRequest()
        fetchRequest.predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            NSPredicate(format: "dog == %@", dog),
            NSPredicate(format: "type == %@", "Walk")
        ])
        
        do {
            let activities = try viewContext.fetch(fetchRequest)
            let totalDuration = activities.reduce(0.0) { $0 + $1.duration }
            return activities.isEmpty ? 0 : totalDuration / Double(activities.count)
        } catch {
            print("Error calculating average walk duration: \(error)")
            return 0
        }
    }
    
    private func averageFeedingsPerDay(for dog: Dog) -> Double {
        let calendar = Calendar.current
        let endDate = Date()
        let startDate = calendar.date(byAdding: .day, value: -7, to: endDate) ?? endDate
        
        let fetchRequest: NSFetchRequest<DogActivity> = DogActivity.fetchRequest()
        fetchRequest.predicate = NSCompoundPredicate(andPredicateWithSubpredicates: [
            NSPredicate(format: "dog == %@", dog),
            NSPredicate(format: "type == %@", "Feed"),
            NSPredicate(format: "date >= %@ AND date <= %@", startDate as NSDate, endDate as NSDate)
        ])
        
        do {
            let feedings = try viewContext.fetch(fetchRequest)
            let dayCount = max(1, calendar.dateComponents([.day], from: startDate, to: endDate).day ?? 1)
            return Double(feedings.count) / Double(dayCount)
        } catch {
            print("Error calculating average feedings: \(error)")
            return 0
        }
    }
    
    private func getDateComponent() -> DateComponents {
        switch selectedTimeRange {
        case .week:
            return DateComponents(day: -7)
        case .month:
            return DateComponents(month: -1)
        case .year:
            return DateComponents(year: -1)
        }
    }
}

struct DogSelectorButton: View {
    let dog: Dog
    let isSelected: Bool
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                if let imageData = dog.image,
                   let uiImage = UIImage(data: imageData) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 50, height: 50)
                        .clipShape(Circle())
                } else {
                    Image(systemName: "pawprint.circle.fill")
                        .font(.system(size: 50))
                }
                
                Text(dog.name ?? "")
                    .font(.caption)
            }
        }
        .padding(8)
        .background(isSelected ? Color.blue.opacity(0.1) : Color.clear)
        .cornerRadius(12)
    }
}

struct ChartCard<Content: View>: View {
    let title: String
    let content: Content
    
    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline)
            
            content
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
        .padding(.horizontal)
    }
}

struct StatCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 30))
                .foregroundColor(color)
            
            VStack(spacing: 4) {
                Text(value)
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text(title)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .frame(maxWidth: .infinity)
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
    }
} 