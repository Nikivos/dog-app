import SwiftUI

struct CalendarView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \DogActivity.date, ascending: true)],
        animation: .default)
    private var activities: FetchedResults<DogActivity>
    
    @State private var selectedDate = Date()
    @State private var showingAddActivity = false
    
    private let calendar = Calendar.current
    private let dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "d"
        return formatter
    }()
    
    private let weekDayFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE"
        return formatter
    }()
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Calendar strip
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(-15...15, id: \.self) { offset in
                            let date = calendar.date(byAdding: .day, value: offset, to: Date()) ?? Date()
                            CalendarDayButton(
                                date: date,
                                isSelected: calendar.isDate(date, inSameDayAs: selectedDate),
                                formatter: dateFormatter,
                                weekDayFormatter: weekDayFormatter
                            ) {
                                selectedDate = date
                            }
                        }
                    }
                    .padding()
                }
                .background(Color(.systemBackground))
                .shadow(radius: 2)
                
                // Activities list
                List {
                    ForEach(activitiesForSelectedDate) { activity in
                        ActivityRow(activity: activity)
                    }
                    .onDelete(perform: deleteActivities)
                }
            }
            .navigationTitle("Calendar")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { showingAddActivity = true }) {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: $showingAddActivity) {
                AddActivityView(selectedDate: selectedDate)
            }
        }
    }
    
    private var activitiesForSelectedDate: [DogActivity] {
        activities.filter { activity in
            guard let activityDate = activity.date else { return false }
            return calendar.isDate(activityDate, inSameDayAs: selectedDate)
        }
    }
    
    private func deleteActivities(offsets: IndexSet) {
        withAnimation {
            offsets.map { activitiesForSelectedDate[$0] }.forEach(viewContext.delete)
            
            do {
                try viewContext.save()
            } catch {
                print("Error deleting activity: \(error)")
            }
        }
    }
}

struct CalendarDayButton: View {
    let date: Date
    let isSelected: Bool
    let formatter: DateFormatter
    let weekDayFormatter: DateFormatter
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            VStack {
                Text(weekDayFormatter.string(from: date))
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                ZStack {
                    Circle()
                        .fill(isSelected ? Color.blue : Color.clear)
                        .frame(width: 35, height: 35)
                    
                    Text(formatter.string(from: date))
                        .foregroundColor(isSelected ? .white : .primary)
                }
                
                if Calendar.current.isDateInToday(date) {
                    Circle()
                        .fill(Color.blue)
                        .frame(width: 4, height: 4)
                }
            }
        }
        .frame(width: 45)
    }
}

struct ActivityRow: View {
    let activity: DogActivity
    
    private let timeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter
    }()
    
    var body: some View {
        HStack {
            Circle()
                .fill(activityColor)
                .frame(width: 10, height: 10)
            
            VStack(alignment: .leading) {
                Text(activity.type ?? "Activity")
                    .font(.headline)
                
                if let date = activity.date {
                    Text(timeFormatter.string(from: date))
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            if let duration = activity.duration, duration > 0 {
                Text("\(Int(duration)) min")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 8)
    }
    
    private var activityColor: Color {
        switch activity.type {
        case "Walk":
            return .green
        case "Feed":
            return .orange
        case "Vet":
            return .red
        default:
            return .blue
        }
    }
}

struct AddActivityView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    
    let selectedDate: Date
    
    @State private var activityType = "Walk"
    @State private var duration = 30.0
    @State private var time = Date()
    @State private var location = ""
    
    private let activityTypes = ["Walk", "Feed", "Vet", "Medicine", "Grooming"]
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Activity Details")) {
                    Picker("Type", selection: $activityType) {
                        ForEach(activityTypes, id: \.self) { type in
                            Text(type).tag(type)
                        }
                    }
                    
                    DatePicker("Time", selection: $time, displayedComponents: .hourAndMinute)
                    
                    if activityType == "Walk" {
                        Stepper("Duration: \(Int(duration)) min", value: $duration, in: 5...180, step: 5)
                        TextField("Location", text: $location)
                    }
                }
            }
            .navigationTitle("New Activity")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Add") {
                        saveActivity()
                    }
                }
            }
        }
    }
    
    private func saveActivity() {
        let activity = DogActivity(context: viewContext)
        activity.id = UUID()
        activity.type = activityType
        
        // Combine selected date with selected time
        let calendar = Calendar.current
        let components = calendar.dateComponents([.hour, .minute], from: time)
        activity.date = calendar.date(bySettingHour: components.hour ?? 0,
                                    minute: components.minute ?? 0,
                                    second: 0,
                                    of: selectedDate)
        
        if activityType == "Walk" {
            activity.duration = duration
            activity.location = location
        }
        
        do {
            try viewContext.save()
            dismiss()
        } catch {
            print("Error saving activity: \(error)")
        }
    }
} 