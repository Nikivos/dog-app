import Foundation
import ZIPFoundation

class ProjectBackupManager {
    static let shared = ProjectBackupManager()
    
    private var documentsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    func createProjectBackup() throws -> URL {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
        let backupName = "DogCareProject_\(dateFormatter.string(from: Date())).zip"
        let backupURL = documentsDirectory.appendingPathComponent(backupName)
        
        // Создаем архив
        guard let archive = Archive(url: backupURL, accessMode: .create) else {
            throw BackupError.archiveCreationFailed
        }
        
        // Список файлов для бэкапа
        let filesToBackup = [
            "DogApp.swift",
            "ContentView.swift",
            "AddDogView.swift",
            "CalendarView.swift",
            "AnalyticsView.swift",
            "KnowledgeBaseView.swift",
            "SettingsView.swift",
            "DataController.swift",
            "BackupManager.swift",
            "LocalizationManager.swift",
            "DogModel.xcdatamodeld",
            "Info.plist",
            "Localizable.strings",
            "ru.lproj/Localizable.strings",
            "Dog.xcodeproj/project.pbxproj"
        ]
        
        // Добавляем файлы в архив
        for file in filesToBackup {
            if let fileURL = Bundle.main.url(forResource: file, withExtension: nil) {
                try archive.addEntry(with: file, fileURL: fileURL)
            }
        }
        
        return backupURL
    }
} 