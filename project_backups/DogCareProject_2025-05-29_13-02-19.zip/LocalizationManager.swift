import Foundation
import SwiftUI

enum LocalizationManager {
    static var currentLanguage: String {
        get {
            UserDefaults.standard.string(forKey: "appLanguage") ?? "en"
        }
        set {
            UserDefaults.standard.set(newValue, forKey: "appLanguage")
            UserDefaults.standard.set([newValue], forKey: "AppleLanguages")
            UserDefaults.standard.synchronize()
        }
    }
    
    static func localizedString(_ key: String) -> String {
        let path = Bundle.main.path(forResource: currentLanguage, ofType: "lproj")
        let bundle = path != nil ? Bundle(path: path!) : Bundle.main
        return NSLocalizedString(key, bundle: bundle ?? Bundle.main, comment: "")
    }
}

extension String {
    var localized: String {
        LocalizationManager.localizedString(self)
    }
}

extension LocalizedStringKey {
    init(_ key: String) {
        self.init(stringLiteral: key)
    }
}

struct LocalizedText: View {
    let key: String
    
    var body: some View {
        Text(LocalizedStringKey(key))
    }
}

extension View {
    func localizedTitle(_ key: String) -> some View {
        navigationTitle(LocalizedStringKey(key))
    }
} 