import CoreData
import SwiftUI
import CloudKit

class DataController: ObservableObject {
    static let shared = DataController()
    
    let container: NSPersistentCloudKitContainer
    private var loadRetryCount = 0
    private let maxRetries = 3
    
    @Published var lastSyncError: String?
    @Published var isSyncing = false
    
    init() {
        container = NSPersistentCloudKitContainer(name: "DogModel")
        
        // Configure CloudKit sync
        guard let description = container.persistentStoreDescriptions.first else {
            fatalError("Failed to retrieve store description")
        }
        
        description.setOption(true as NSNumber, forKey: NSPersistentStoreRemoteChangeNotificationPostOptionKey)
        description.cloudKitContainerOptions = NSPersistentCloudKitContainerOptions(containerIdentifier: "iCloud.com.example.dogcare")
        
        loadStore()
        setupNotifications()
    }
    
    private func loadStore() {
        container.loadPersistentStores { [weak self] description, error in
            if let error = error {
                print("Core Data failed to load: \(error.localizedDescription)")
                
                // Retry logic
                guard let self = self, self.loadRetryCount < self.maxRetries else {
                    print("Max retries reached, giving up")
                    return
                }
                
                self.loadRetryCount += 1
                print("Retrying store load (attempt \(self.loadRetryCount))")
                
                // Wait 2 seconds before retrying
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    self.loadStore()
                }
            } else {
                self?.setupContainer()
            }
        }
    }
    
    private func setupContainer() {
        container.viewContext.automaticallyMergesChangesFromParent = true
        container.viewContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy
        
        // Enable CloudKit sync error handling
        container.viewContext.transactionAuthor = "app"
        
        // Set up save points
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(managedObjectContextObjectsDidChange),
            name: NSManagedObjectContext.didChangeNotification,
            object: container.viewContext
        )
    }
    
    private func setupNotifications() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(storeRemoteChange),
            name: .NSPersistentStoreRemoteChange,
            object: container.persistentStoreCoordinator
        )
    }
    
    @objc private func storeRemoteChange(_ notification: Notification) {
        print("Received remote store change notification")
        syncChanges()
    }
    
    @objc private func managedObjectContextObjectsDidChange(_ notification: Notification) {
        guard let context = notification.object as? NSManagedObjectContext,
              context === container.viewContext else { return }
        
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                print("Error saving context: \(error)")
            }
        }
    }
    
    func syncChanges() {
        guard !isSyncing else { return }
        isSyncing = true
        
        container.performBackgroundTask { [weak self] context in
            do {
                try context.save()
                DispatchQueue.main.async {
                    self?.isSyncing = false
                    self?.lastSyncError = nil
                }
            } catch {
                DispatchQueue.main.async {
                    self?.isSyncing = false
                    self?.lastSyncError = error.localizedDescription
                    print("Sync error: \(error)")
                }
            }
        }
    }
    
    func retrySync() {
        syncChanges()
    }
    
    func handleError(_ error: Error) {
        if let cloudError = error as? CKError {
            switch cloudError.code {
            case .networkUnavailable, .networkFailure:
                // Retry after network becomes available
                DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak self] in
                    self?.retrySync()
                }
            case .quotaExceeded:
                lastSyncError = "iCloud storage quota exceeded"
            case .serverResponseLost, .serviceUnavailable:
                // Retry with exponential backoff
                DispatchQueue.main.asyncAfter(deadline: .now() + 10) { [weak self] in
                    self?.retrySync()
                }
            default:
                lastSyncError = cloudError.localizedDescription
            }
        } else {
            lastSyncError = error.localizedDescription
        }
    }
} 